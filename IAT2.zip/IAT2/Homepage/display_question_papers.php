<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "IAT";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch question papers along with their status
$query = "SELECT QP_code, Subject_code, Sem, QP, Status FROM Question_paper";
$result = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question Papers</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Question Papers</h2>

<?php
if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>QP Code</th><th>Subject Code</th><th>Semester</th><th>QP</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['QP_code'] . "</td>";
        echo "<td>" . $row['Subject_code'] . "</td>";
        echo "<td>" . $row['Sem'] . "</td>";
        echo "<td><a href='downloadpaper.php?file=" . urlencode($row['QP']) . "'>Download QP</a></td>";
        //echo "<td><a href='". $row['QP'] . "' target='_blank'>View QP</a></td>";
        echo "<td>" . $row['Status'] . "</td>";
        echo "</tr>";
    
    }
    echo "</table>";
} else {
    echo "No question papers found.";
}

$conn->close();
?>

</body>
</html>
