<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "IAT";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve and display all feedback
$result = $conn->query("SELECT * FROM feedback");

if ($result->num_rows > 0) {
    echo "<h2>Received Feedback Data:</h2>";
    echo "<table border='1' cellpadding='10' cellspacing='0' style='border-collapse: collapse; width: 100%;'>
            <thead>
            <tr>
                <th>ID</th>
                <th>Gmail</th>
                <th>Criteria</th>
                <th>COs</th>
                <th>Taxonomy</th>
                <th>Grading</th>
                <th>Course Name</th>
                <th>Course Code</th>
                <th>Semester</th>
                <th>Section</th>
            </tr>
            </thead>
            <tbody>";
    
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["id"] . "</td>
                <td>" . htmlspecialchars($row["Gmail"]) . "</td>
                <td>" . htmlspecialchars($row["Criteria"]) . "</td>
                <td>" . htmlspecialchars($row["COs"]) . "</td>
                <td>" . htmlspecialchars($row["Taxonomy"]) . "</td>
                <td>" . htmlspecialchars($row["Grading"]) . "</td>
                <td>" . htmlspecialchars($row["CourseName"]) . "</td>
                <td>" . htmlspecialchars($row["CourseCode"]) . "</td>
                <td>" . htmlspecialchars($row["Semester"]) . "</td>
                <td>" . htmlspecialchars($row["Section"]) . "</td>
            </tr>";
    }
    
    echo "</tbody></table>";
} else {
    echo "No feedback found.";
}

// Close connection
$conn->close();
?>
