<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "IAT";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $gmail = isset($_POST['Gmail']) ? $_POST['Gmail'] : null;
    $criteria = isset($_POST['Criteria']) ? $_POST['Criteria'] : null;
    $cos = isset($_POST['COs']) ? $_POST['COs'] : null;
    $taxonomy = isset($_POST['Taxonomy']) ? $_POST['Taxonomy'] : null;
    $grading = isset($_POST['Grading']) ? $_POST['Grading'] : null;
    $courseName = isset($_POST['CourseName']) ? $_POST['CourseName'] : null;
    $courseCode = isset($_POST['CourseCode']) ? $_POST['CourseCode'] : null;
    $semester = isset($_POST['Semester']) ? $_POST['Semester'] : null;
    $section = isset($_POST['Section']) ? $_POST['Section'] : null;

    // Validate required fields
    if ($gmail && $criteria && $cos && $taxonomy && $grading && $courseName && $courseCode && $semester && $section) {
        // Insert data into database
        $stmt = $conn->prepare("INSERT INTO feedback (Gmail, Criteria, COs, Taxonomy, Grading, CourseName, CourseCode, Semester, Section) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssis", $gmail, $criteria, $cos, $taxonomy, $grading, $courseName, $courseCode, $semester, $section);

        if ($stmt->execute()) {
            echo "Feedback submitted successfully.<br><br>";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "All fields are required.<br><br>";
    }
}

// Close connection
$conn->close();
?>

