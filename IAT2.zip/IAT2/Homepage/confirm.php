<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "IAT";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$QP_code = $_POST['QP_code'];
$confirmation = $_POST['confirmation'];

// Update Confirmed field
$q1 = "UPDATE Question_paper SET Confirmed = '$confirmation' WHERE QP_code = '$QP_code'";
$res1 = mysqli_query($conn, $q1);

// Check if the update was successful
if ($res1 === FALSE) {
    die("Error in executing query q1: " . mysqli_error($conn));
}

// Verify the update by fetching the updated row (for example purposes, not necessary for your logic)
$q1_check = "SELECT * FROM Question_paper WHERE QP_code = '$QP_code'";
$res1_check = mysqli_query($conn, $q1_check);

if ($res1_check === FALSE) {
    die("Error in executing query q1_check: " . mysqli_error($conn));
}

$row = mysqli_fetch_assoc($res1_check);

// Update VerifiedbyCCI field
$q2 = "UPDATE Question_paper SET VerifiedbyCCI = 1 WHERE QP_code = '$QP_code'";

if ($conn->query($q2) === TRUE) {
    header("Location: CCIHome.php");
    exit;
} else {
    echo "Error in executing query q2: " . $conn->error;
}

// Close the connection
mysqli_close($conn);
?>
