<?php 
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "IAT";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>

<!DOCTYPE html>
<html>
<head>
    <title>CIE QP Scrutinizing Committee Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            margin: 20px;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            flex: 1;
        }
        form {
            max-width: 600px;
        }
        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="number"], textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="radio"] {
            margin-top: 5px;
            margin-right: 5px;
        }
        button {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .btn-row {
            display: flex;
            gap: 10px; /* Space between buttons */
        }
        .radio-group {
            display: flex;
            align-items: center;
            margin-top: 5px;
        }
        .radio-group input {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <h1>CIE QP Scrutinizing Committee</h1>
    <p>The committee members are also requested to make the corresponding remarks to ensure the quality of CIE question papers.</p>
    <div class="container">
        <div class="form-container">
            <form action="submit_feedback.php" method="POST">
                <label for="Gmail">GMAIL *</label>
                <input type="email" id="Gmail" name="Gmail" required>

                <label>Do the questions meet the outcome-based education criteria? *</label>
                <div class="radio-group">
                    <input type="radio" id="CriteriaYes" name="Criteria" value="Yes" required>
                    <label for="CriteriaYes">Yes</label>
                    <input type="radio" id="CriteriaNo" name="Criteria" value="No">
                    <label for="CriteriaNo">No</label>
                </div>

                <label>Does the question cover the relevant course outcomes (COs)? *</label>
                <div class="radio-group">
                    <input type="radio" id="COsYes" name="COs" value="Yes" required>
                    <label for="COsYes">Yes</label>
                    <input type="radio" id="COsNo" name="COs" value="No">
                    <label for="COsNo">No</label>
                </div>

                <label>Do the questions meet the different levels of Bloom's taxonomy? *</label>
                <div class="radio-group">
                    <input type="radio" id="TaxonomyYes" name="Taxonomy" value="Yes" required>
                    <label for="TaxonomyYes">Yes</label>
                    <input type="radio" id="TaxonomyNo" name="Taxonomy" value="No">
                    <label for="TaxonomyNo">No</label>
                </div>

                <label>Overall grading of the question *</label>
                <div class="radio-group">
                    <input type="radio" id="GradingGood" name="Grading" value="Good" required>
                    <label for="GradingGood">Good</label>
                    <input type="radio" id="GradingAverage" name="Grading" value="Average">
                    <label for="GradingAverage">Average</label>
                    <input type="radio" id="GradingPoor" name="Grading" value="Poor">
                    <label for="GradingPoor">Poor</label>
                </div>

                <label for="CourseName">Course Name *</label>
                <input type="text" id="CourseName" name="CourseName" required>

                <label for="CourseCode">Course Code *</label>
                <input type="text" id="CourseCode" name="CourseCode" required>

                <label for="Semester">Semester *</label>
                <input type="number" id="Semester" name="Semester" required>

                <label for="Section">Section *</label>
                <div class="radio-group">
                    <input type="radio" id="SectionA" name="Section" value="A" required>
                    <label for="SectionA">A</label>
                    <input type="radio" id="SectionB" name="Section" value="B">
                    <label for="SectionB">B</label>
                    <input type="radio" id="SectionCSD" name="Section" value="CSD">
                    <label for="SectionCSD">CSD</label>
                </div>

                <button type="submit">Submit</button>
            </form>
        </div>
    </div>
</body>
</html>
