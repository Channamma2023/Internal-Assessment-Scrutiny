<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "IAT";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $qp_code = $_POST['qp_code'];
    $status = $_POST['status'];

    // Update status in the database
    $update_query = "UPDATE Question_paper SET Status = ? WHERE QP_code = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("si", $status, $qp_code);
    if ($stmt->execute()) {
        echo "Status updated successfully.";
    } else {
        echo "Error updating status: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>
